#include <stdio.h>

int main()
{
  printf("Hello world!\n");
  printf("This is c deb package.\n");
}
